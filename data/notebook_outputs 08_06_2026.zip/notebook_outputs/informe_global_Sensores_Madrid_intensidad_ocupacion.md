# Informe Global Comparativo — Sensores_Madrid

*Generado el 2026-05-25 | 1 fuente de datos analizada | 19 patrones en total*

## ¿Cómo se comporta **intensidad, ocupacion** en Sensores_Madrid?

> Esta sección resume los hallazgos principales en lenguaje sencillo, sin tecnicismos. Los detalles técnicos se encuentran en las secciones siguientes.

Se ha analizado **1 fuente de datos** (DailyDelhiClimateTrain), detectando **19 patrones** de comportamiento estadísticamente significativos.

## Tabla comparativa global

Cada fila representa una fuente de datos. La columna **Perfil del día** muestra el nivel de **trafico** dominante en cada franja (Madrugada | Mañana | Tarde | Noche): 🔴 excepcional · 🟠 muy alto · 🟡 alto · 🟢 moderado · 🔵 bajo · 🟣 muy bajo · ⚪ mínimo.

| Sensor                 | Métrica   |   Reglas |   Conf. media (%) |   Lift medio |   Lift máx | Nivel dominante   | Perfil del día                             | Hora más mencionada en reglas   | Día más mencionado   | Outlier alto   | Outlier bajo   |
|:-----------------------|:----------|---------:|------------------:|-------------:|-----------:|:------------------|:-------------------------------------------|:--------------------------------|:---------------------|:---------------|:---------------|
| DailyDelhiClimateTrain | meantemp  |       19 |              59.6 |         3.35 |       5.97 | 🔵 baja           | Madrugada — | Mañana — | Tarde — | Noche — |                                 | Lunes                | —              | ✅             |

## Análisis técnico comparativo

El presente informe recoge los resultados del análisis difuso sobre **1 fuente de datos** (DailyDelhiClimateTrain), con un total de 19 reglas de asociación significativas. La confianza media es del 59.6 %.

### Patrones compartidos entre fuentes de datos

> ℹ️ El análisis comparativo de patrones compartidos requiere al menos 2 fuentes de datos.

### Fuentes con comportamiento atípico

Ninguna fuente de datos muestra desviaciones marcadas respecto al comportamiento medio del grupo en las métricas globales.

---

## Análisis detallado por fuente de datos

Para el desglose completo de reglas, visualizaciones y narrativa, consultar los informes individuales generados por `src03`:

- [DailyDelhiClimateTrain — Meantemp](./DailyDelhiClimateTrain_meantemp_resumen.md)
