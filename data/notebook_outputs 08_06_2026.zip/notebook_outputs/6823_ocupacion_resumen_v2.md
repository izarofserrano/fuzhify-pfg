---
**Fuzhify**: Informe de análisis difuso

| | |
|---|---|
| **Dataset** | 6823 |
| **Métrica** | ocupacion |
| **Fecha** | 07/06/2026 |
| **min_soporte** | 0.005 |
| **min_confianza** | 0.5 |
| **lift_minimo** | 1.0 |
| **max_prof** | 3 |
| **k_beam** | 10 |
| **top_por_consecuente** | 10 |
| **pais** | ES |
| **subdiv** | nacional |
| **min_reglas_grupo** | 2 |

---

# Resumen de comportamiento: 6823

**Métrica analizada:** Ocupacion  
**Total de reglas analizadas:** 36

> ### Niveles de la métrica analizada (ocupacion) 
> Escala desde **excepcionalmente bajo** hasta **excepcionalmente alto**, calculada a partir de la desviación sobre la media histórica del propio sensor.
>
> Cuando el patrón es *muy diferenciado* del comportamiento normal se describe *'de forma notable'* o *'muy marcada'*. Cuando es solo una *tendencia*, se dice así.
## ¿Cómo se comporta **ocupacion** a lo largo del día?
> Esta sección resume el comportamiento de **ocupacion** en lenguaje sencillo, sin tecnicismos.

De madrugada (0–6 h), el ocupacion es **muy bajo**. Al llegar la mañana (7–13 h), el ocupacion sube hasta niveles **moderado**, en días laborables; se reduce sensiblemente en fin de semana, con un patrón distinto en agosto. Por la tarde (14–20 h), el ocupacion se mantiene **moderado**, especialmente entre semana, con calma en fin de semana, aunque agosto rompe este patrón. Al caer la noche (21–23 h), el ocupacion queda en un nivel **bajo**.

Los **fines de semana** el ocupacion se reduce respecto a los días laborables, aunque sin llegar a invertir el patrón general. Los **festivos** se comportan de forma similar al fin de semana con independencia del día de la semana en que caigan.

## Análisis por franja horaria

Detalle de los patrones detectados, organizados por momento del día. Cada punto indica el nivel de ocupacion más probable en ese contexto, junto con la confianza y el lift de la regla.

### Madrugada (0–6 h)

- **Baja** de forma muy marcada: las 6 h en los sábados (confianza 91 %, lift 3.5)
- **Baja** de forma notable: las 0 h (confianza 72 %, lift 2.8)
- **Baja** con cierta consistencia: las 1 h en el año 2025 (confianza 52 %, lift 2.0)
- **Baja** con cierta consistencia: las 5 h (confianza 51 %, lift 2.0)
- **Muy baja** de forma muy marcada: las 3 h (confianza 84 %, lift 5.3)
- **Muy baja** de forma muy marcada: las 4 h (confianza 79 %, lift 5.0)
- **Muy baja** de forma muy marcada: las 2 h (confianza 75 %, lift 4.8)
- **Muy baja** de forma muy marcada: las 1 h (confianza 58 %, lift 3.7)
- **Muy baja** de forma muy marcada: la madrugada (0–6 h) en el año 2024 (confianza 51 %, lift 3.3)

### Mañana (7–13 h)

- **Excepcionalmente alta (outlier superior)** de forma muy marcada: las 7 h en días laborables (confianza 52 %, lift 11.6)
- **Muy alta** de forma muy marcada: las 8 h en días laborables (confianza 59 %, lift 4.1)
- **Muy alta** de forma muy marcada: las 7 h (confianza 56 %, lift 3.9)
- **Muy alta** de forma muy marcada: las 9 h en días laborables (confianza 54 %, lift 3.7)
- **Alta** de forma notable: las 12 h (confianza 59 %, lift 2.3)
- **Alta** de forma notable: las 13 h (confianza 59 %, lift 2.2)
- **Alta** con cierta consistencia: las 11 h (confianza 52 %, lift 2.0)
- **Media** de forma muy marcada: las 11 h en los domingos (confianza 71 %, lift 4.0)
- **Media** de forma muy marcada: las 13 h en agosto (confianza 67 %, lift 3.8)
- **Media** de forma muy marcada: las 11 h en los sábados (confianza 63 %, lift 3.6)
- **Media** de forma muy marcada: las 9 h en los sábados (confianza 57 %, lift 3.2)

### Tarde (14–20 h)

- **Alta** de forma notable: las 18 h (confianza 62 %, lift 2.4)
- **Alta** de forma notable: las 19 h (confianza 61 %, lift 2.3)
- **Alta** de forma notable: las 14 h en el año 2024 (confianza 55 %, lift 2.1)
- **Alta** de forma notable: la tarde (14–20 h) en días laborables (confianza 54 %, lift 2.1)
- **Alta** de forma notable: las 17 h (confianza 53 %, lift 2.0)
- **Media** de forma muy marcada: las 16 h en los sábados (confianza 59 %, lift 3.3)
- **Media** de forma muy marcada: la tarde (14–20 h) en agosto (confianza 59 %, lift 3.3)
- **Media** de forma muy marcada: las 16 h en los domingos (confianza 57 %, lift 3.2)
- **Media** de forma notable: las 20 h (confianza 52 %, lift 3.0)

### Noche (21–23 h)

- **Media** de forma muy marcada: las 21 h (confianza 56 %, lift 3.2)
- **Baja** de forma muy marcada: las 23 h (confianza 91 %, lift 3.5)
- **Baja** de forma notable: las 22 h (confianza 77 %, lift 3.0)

---

## Análisis por nivel de ocupacion


> ### Glosario técnico (apéndice)
> * **Confianza:** probabilidad (0–100 %) de que el patrón sea cierto cuando se da el contexto. Confianza 80 % significa que, en ese contexto, el la métrica se comporta así 8 de cada 10 veces.
> * **Lift:** cuántas veces más probable es el evento respecto al azar. Lift 5.0 significa que el patrón es 5 veces más frecuente en ese contexto que en el resto del tiempo.
> * **Outlier inferior/superior:** valor más allá de 2 desviaciones típicas de la media histórica del sensor.

*Mismas reglas organizadas por nivel de **ocupacion** (de mayor a menor valor).*

### Ocupacion excepcionalmente alta (outlier superior)
*1 regla, agrupadas en 1 contexto | confianza media: 52 %, lift medio: 11.6*

A las 7 h en días laborables, la ocupacion tiende a ser excepcionalmente alta (outlier superior) de forma muy marcada (confianza 52 %, lift 11.6).

### Ocupacion muy alta
*3 reglas, agrupadas en 2 contextos | confianza media: 56 %, lift medio: 3.9*

En el contexto de días laborables, la ocupacion tiende a ser muy alta, especialmente en las 8 h (59 %) y las 9 h (54 %). Este patrón se observa con una confianza media del 57 % y un lift máximo de 4.1.

A las 7 h, la ocupacion tiende a ser muy alta de forma muy marcada (confianza 56 %, lift 3.9).

### Ocupacion alta
*8 reglas, agrupadas en 8 contextos | confianza media: 57 %, lift medio: 2.2*

A las 18 h, la ocupacion tiende a ser alta de forma notable (confianza 62 %, lift 2.4).

A las 19 h, la ocupacion tiende a ser alta de forma notable (confianza 61 %, lift 2.3).

A las 12 h, la ocupacion tiende a ser alta de forma notable (confianza 59 %, lift 2.3).

A las 13 h, la ocupacion tiende a ser alta de forma notable (confianza 59 %, lift 2.2).

A las 14 h en el año 2024, la ocupacion tiende a ser alta de forma notable (confianza 55 %, lift 2.1).

Durante la tarde (14–20 h) en días laborables, la ocupacion tiende a ser alta de forma notable (confianza 54 %, lift 2.1).

A las 17 h, la ocupacion tiende a ser alta de forma notable (confianza 53 %, lift 2.0).

A las 11 h, la ocupacion tiende a ser alta con cierta consistencia (confianza 52 %, lift 2.0).

### Ocupacion media
*9 reglas, agrupadas en 7 contextos | confianza media: 60 %, lift medio: 3.4*

En el contexto de las 11 h, la ocupacion tiende a ser media, especialmente en los domingos (71 %) y los sábados (63 %). Este patrón se observa con una confianza media del 67 % y un lift máximo de 4.0.

A las 13 h en agosto, la ocupacion tiende a ser media de forma muy marcada (confianza 67 %, lift 3.8).

En el contexto de las 16 h, la ocupacion tiende a ser media, especialmente en los sábados (59 %) y los domingos (57 %). Este patrón se observa con una confianza media del 58 % y un lift máximo de 3.3.

Durante la tarde (14–20 h) en agosto, la ocupacion tiende a ser media de forma muy marcada (confianza 59 %, lift 3.3).

A las 9 h en los sábados, la ocupacion tiende a ser media de forma muy marcada (confianza 57 %, lift 3.2).

A las 21 h, la ocupacion tiende a ser media de forma muy marcada (confianza 56 %, lift 3.2).

A las 20 h, la ocupacion tiende a ser media de forma notable (confianza 52 %, lift 3.0).

### Ocupacion baja
*10 reglas, agrupadas en 9 contextos | confianza media: 64 %, lift medio: 2.5*

A las 23 h, la ocupacion tiende a ser baja de forma muy marcada (confianza 91 %, lift 3.5).

A las 6 h en los sábados, la ocupacion tiende a ser baja de forma muy marcada (confianza 91 %, lift 3.5).

A las 22 h, la ocupacion tiende a ser baja de forma notable (confianza 77 %, lift 3.0).

A las 0 h, la ocupacion tiende a ser baja de forma notable (confianza 72 %, lift 2.8).

En el contexto de los domingos, la ocupacion tiende a ser baja, especialmente en el año 2024 (52 %) y la segunda quincena del mes (50 %). Este patrón se observa con una confianza media del 51 % y un lift máximo de 2.0.

En días festivos, la ocupacion tiende a ser baja con cierta consistencia (confianza 52 %, lift 2.0).

A las 1 h en el año 2025, la ocupacion tiende a ser baja con cierta consistencia (confianza 52 %, lift 2.0).

Durante los fin de semana en verano, la ocupacion tiende a ser baja con cierta consistencia (confianza 51 %, lift 2.0).

A las 5 h, la ocupacion tiende a ser baja con cierta consistencia (confianza 51 %, lift 2.0).

### Ocupacion muy baja
*5 reglas, agrupadas en 5 contextos | confianza media: 70 %, lift medio: 4.4*

A las 3 h, la ocupacion tiende a ser muy baja de forma muy marcada (confianza 84 %, lift 5.3).

A las 4 h, la ocupacion tiende a ser muy baja de forma muy marcada (confianza 79 %, lift 5.0).

A las 2 h, la ocupacion tiende a ser muy baja de forma muy marcada (confianza 75 %, lift 4.8).

A las 1 h, la ocupacion tiende a ser muy baja de forma muy marcada (confianza 58 %, lift 3.7).

Durante la madrugada (0–6 h) en el año 2024, la ocupacion tiende a ser muy baja de forma muy marcada (confianza 51 %, lift 3.3).

---

## Estadísticas globales del análisis

| Métrica | Valor |
|---|---|
| Reglas totales | 36 |
| Consecuentes únicos | 6 |
| Soporte medio | 0.0633 |
| Confianza media | 61.1 % |
| Lift medio | 3.28 |
| Lift máximo | 11.63 |