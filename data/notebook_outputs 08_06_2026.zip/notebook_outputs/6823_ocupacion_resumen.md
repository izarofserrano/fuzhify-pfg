# Resumen de comportamiento — Sensor 6823

**Métrica analizada:** Ocupación de la vía  
**Total de reglas analizadas:** 36

> ### 📖 Niveles de tráfico
> Escala desde **excepcionalmente bajo** ⚪ hasta **excepcionalmente alto** 🔴, calculada a partir de la desviación sobre la media histórica del propio sensor.
>
> Cuando el patrón es *muy diferenciado* del comportamiento normal se describe *'de forma notable'* o *'muy marcada'*. Cuando es solo una *tendencia*, se dice así.
## Visualizaciones

### Mapa de calor hora × día de la semana
![Mapa de calor hora x día](data/6823_ocupacion_heatmap.png)

### Reglas por fuerza de asociación (lift)
![Barras lift](data/6823_ocupacion_barras_lift.png)

### Soporte vs Confianza
![Scatter soporte-confianza](data/6823_ocupacion_scatter.png)

### Resumen por categoría
![Tabla consecuentes](data/6823_ocupacion_tabla_consecuentes.png)

## ¿Cómo se comporta el tráfico a lo largo del día?

> Esta sección resume el comportamiento del tráfico en lenguaje sencillo, sin tecnicismos. Cada patrón se ha detectado automáticamente a partir de los datos reales del sensor.

De madrugada (0–6 h), el tráfico es **muy escaso** 🟣. Al llegar la mañana (7–13 h), el tráfico sube hasta niveles **moderado** 🟢, en días laborables; se reduce sensiblemente en fin de semana, con un patrón distinto en agosto. Por la tarde (14–20 h), el tráfico se mantiene **moderado** 🟢, especialmente entre semana, con calma en fin de semana, aunque agosto rompe este patrón. Al caer la noche (21–23 h), el tráfico queda en un nivel **escaso** 🔵.

Los **fines de semana** el tráfico se reduce respecto a los días laborables, aunque sin llegar a invertir el patrón general. Los **festivos** se comportan de forma similar al fin de semana con independencia del día de la semana en que caigan.

## Análisis por franja horaria

Detalle de los patrones detectados, organizados por momento del día. Cada punto indica el nivel de tráfico más probable en ese contexto, junto con la confianza y el lift de la regla.

### Madrugada (0–6 h)

- 🔵 **Baja** de forma notable: las 6 h en los sábados (confianza 91 %, lift 3.5)
- 🔵 **Baja** con cierta consistencia: las 0 h (confianza 72 %, lift 2.8)
- 🔵 **Baja** con cierta consistencia: la madrugada (0–6 h) en fin de semana (confianza 68 %, lift 2.6)
- 🔵 **Baja** con cierta tendencia: las 1 h en el año 2025 (confianza 52 %, lift 2.0)
- 🟣 **Muy baja** de forma muy marcada: las 3 h (confianza 84 %, lift 5.3)
- 🟣 **Muy baja** de forma muy marcada: las 4 h (confianza 79 %, lift 5.0)
- 🟣 **Muy baja** de forma muy marcada: las 2 h (confianza 75 %, lift 4.8)
- 🟣 **Muy baja** de forma notable: las 1 h (confianza 58 %, lift 3.7)
- 🟣 **Muy baja** de forma notable: la madrugada (0–6 h) en el año 2024 (confianza 51 %, lift 3.3)

### Mañana (7–13 h)

- 🔴 **Excepcionalmente alta (outlier superior)** de forma muy marcada: las 7 h en días laborables (confianza 52 %, lift 11.6)
- 🟠 **Muy alta** de forma notable: las 8 h en días laborables (confianza 59 %, lift 4.1)
- 🟠 **Muy alta** de forma notable: las 7 h (confianza 56 %, lift 3.9)
- 🟠 **Muy alta** de forma notable: las 9 h en días laborables (confianza 54 %, lift 3.7)
- 🟡 **Alta** con cierta tendencia: las 12 h (confianza 59 %, lift 2.3)
- 🟡 **Alta** con cierta tendencia: las 13 h (confianza 59 %, lift 2.2)
- 🟡 **Alta** con cierta tendencia: las 11 h (confianza 52 %, lift 2.0)
- 🟢 **Media** de forma notable: las 11 h en los domingos (confianza 71 %, lift 4.0)
- 🟢 **Media** de forma notable: las 13 h en agosto (confianza 67 %, lift 3.8)
- 🟢 **Media** de forma notable: las 11 h en los sábados (confianza 63 %, lift 3.6)
- 🟢 **Media** de forma notable: las 9 h en los sábados (confianza 57 %, lift 3.2)
- 🔵 **Baja** de forma notable: las 8 h en fin de semana (confianza 84 %, lift 3.2)

### Tarde (14–20 h)

- 🟡 **Alta** con cierta tendencia: las 18 h (confianza 62 %, lift 2.4)
- 🟡 **Alta** con cierta tendencia: las 19 h (confianza 61 %, lift 2.3)
- 🟡 **Alta** con cierta tendencia: las 14 h en el año 2024 (confianza 55 %, lift 2.1)
- 🟡 **Alta** con cierta tendencia: la tarde (14–20 h) en días laborables (confianza 54 %, lift 2.1)
- 🟡 **Alta** con cierta tendencia: las 17 h (confianza 53 %, lift 2.0)
- 🟢 **Media** de forma notable: las 16 h en los sábados (confianza 59 %, lift 3.3)
- 🟢 **Media** de forma notable: la tarde (14–20 h) en agosto (confianza 59 %, lift 3.3)
- 🟢 **Media** de forma notable: las 16 h en los domingos (confianza 57 %, lift 3.2)
- 🟢 **Media** con cierta consistencia: las 20 h (confianza 52 %, lift 3.0)

### Noche (21–23 h)

- 🟢 **Media** con cierta consistencia: las 21 h (confianza 56 %, lift 3.2)
- 🔵 **Baja** de forma notable: las 23 h (confianza 91 %, lift 3.5)
- 🔵 **Baja** con cierta consistencia: las 22 h (confianza 77 %, lift 3.0)

---

## Apéndice — Análisis por nivel de tráfico


> ### 📖 Glosario técnico (apéndice)
> * **Confianza:** probabilidad (0–100 %) de que el patrón sea cierto cuando se da el contexto. Confianza 80 % significa que, en ese contexto, el tráfico se comporta así 8 de cada 10 veces.
> * **Lift:** cuántas veces más probable es el evento respecto al azar. Lift 5.0 significa que el patrón es 5 veces más frecuente en ese contexto que en el resto del tiempo.
> * **Outlier inferior/superior:** valor más allá de 2 desviaciones típicas de la media histórica del sensor.

*Mismas reglas organizadas por nivel de tráfico (de mayor a menor intensidad). 

### 🔴 Ocupación de la vía excepcionalmente alta (outlier superior)
*1 regla — agrupadas en 1 contexto* | confianza media: 52 %, lift medio: 11.6 

A las 7 h en días laborables, la ocupación de la vía tiende a ser excepcionalmente alta (outlier superior) de forma muy marcada (confianza 52 %, lift 11.6).

### 🟠 Ocupación de la vía muy alta
*3 reglas — agrupadas en 2 contextos* | confianza media: 56 %, lift medio: 3.9 

En el contexto de días laborables, la ocupación de la vía tiende a ser muy alta, especialmente en las 8 h (59 %) y las 9 h (54 %). Este patrón se observa con una confianza media del 57 % y un lift máximo de 4.1.

A las 7 h, la ocupación de la vía tiende a ser muy alta de forma notable (confianza 56 %, lift 3.9).

### 🟡 Ocupación de la vía alta
*8 reglas — agrupadas en 8 contextos* | confianza media: 57 %, lift medio: 2.2 

A las 18 h, la ocupación de la vía tiende a ser alta con cierta tendencia (confianza 62 %, lift 2.4).

A las 19 h, la ocupación de la vía tiende a ser alta con cierta tendencia (confianza 61 %, lift 2.3).

A las 12 h, la ocupación de la vía tiende a ser alta con cierta tendencia (confianza 59 %, lift 2.3).

A las 13 h, la ocupación de la vía tiende a ser alta con cierta tendencia (confianza 59 %, lift 2.2).

A las 14 h en el año 2024, la ocupación de la vía tiende a ser alta con cierta tendencia (confianza 55 %, lift 2.1).

Durante la tarde (14–20 h) en días laborables, la ocupación de la vía tiende a ser alta con cierta tendencia (confianza 54 %, lift 2.1).

A las 17 h, la ocupación de la vía tiende a ser alta con cierta tendencia (confianza 53 %, lift 2.0).

A las 11 h, la ocupación de la vía tiende a ser alta con cierta tendencia (confianza 52 %, lift 2.0).

### 🟢 Ocupación de la vía media
*9 reglas — agrupadas en 7 contextos* | confianza media: 60 %, lift medio: 3.4 

En el contexto de las 11 h, la ocupación de la vía tiende a ser media, especialmente en los domingos (71 %) y los sábados (63 %). Este patrón se observa con una confianza media del 67 % y un lift máximo de 4.0.

A las 13 h en agosto, la ocupación de la vía tiende a ser media de forma notable (confianza 67 %, lift 3.8).

En el contexto de las 16 h, la ocupación de la vía tiende a ser media, especialmente en los sábados (59 %) y los domingos (57 %). Este patrón se observa con una confianza media del 58 % y un lift máximo de 3.3.

Durante la tarde (14–20 h) en agosto, la ocupación de la vía tiende a ser media de forma notable (confianza 59 %, lift 3.3).

A las 9 h en los sábados, la ocupación de la vía tiende a ser media de forma notable (confianza 57 %, lift 3.2).

A las 21 h, la ocupación de la vía tiende a ser media con cierta consistencia (confianza 56 %, lift 3.2).

A las 20 h, la ocupación de la vía tiende a ser media con cierta consistencia (confianza 52 %, lift 3.0).

### 🔵 Ocupación de la vía baja
*10 reglas — agrupadas en 10 contextos* | confianza media: 70 %, lift medio: 2.7 

A las 23 h, la ocupación de la vía tiende a ser baja de forma notable (confianza 91 %, lift 3.5).

A las 6 h en los sábados, la ocupación de la vía tiende a ser baja de forma notable (confianza 91 %, lift 3.5).

A las 8 h en fin de semana, la ocupación de la vía tiende a ser baja de forma notable (confianza 84 %, lift 3.2).

A las 22 h, la ocupación de la vía tiende a ser baja con cierta consistencia (confianza 77 %, lift 3.0).

A las 0 h, la ocupación de la vía tiende a ser baja con cierta consistencia (confianza 72 %, lift 2.8).

Durante la madrugada (0–6 h) en fin de semana, la ocupación de la vía tiende a ser baja con cierta consistencia (confianza 68 %, lift 2.6).

Durante los fin de semana en agosto, la ocupación de la vía tiende a ser baja con cierta tendencia (confianza 60 %, lift 2.3).

En los domingos en el año 2024, la ocupación de la vía tiende a ser baja con cierta tendencia (confianza 52 %, lift 2.0).

En días festivos, la ocupación de la vía tiende a ser baja con cierta tendencia (confianza 52 %, lift 2.0).

A las 1 h en el año 2025, la ocupación de la vía tiende a ser baja con cierta tendencia (confianza 52 %, lift 2.0).

### 🟣 Ocupación de la vía muy baja
*5 reglas — agrupadas en 5 contextos* | confianza media: 70 %, lift medio: 4.4 

A las 3 h, la ocupación de la vía tiende a ser muy baja de forma muy marcada (confianza 84 %, lift 5.3).

A las 4 h, la ocupación de la vía tiende a ser muy baja de forma muy marcada (confianza 79 %, lift 5.0).

A las 2 h, la ocupación de la vía tiende a ser muy baja de forma muy marcada (confianza 75 %, lift 4.8).

A las 1 h, la ocupación de la vía tiende a ser muy baja de forma notable (confianza 58 %, lift 3.7).

Durante la madrugada (0–6 h) en el año 2024, la ocupación de la vía tiende a ser muy baja de forma notable (confianza 51 %, lift 3.3).

---

## Estadísticas globales del análisis

| Métrica | Valor |
|---|---|
| Reglas totales | 36 |
| Consecuentes únicos | 6 |
| Soporte medio | 0.0606 |
| Confianza media | 62.8 % |
| Lift medio | 3.34 |
| Lift máximo | 11.63 |