---
**Fuzhify**: Informe de análisis difuso

| | |
|---|---|
| **Dataset** | delhi |
| **Métrica** | meantemp |
| **Fecha** | 07/06/2026 |
| **min_soporte** | 0.005 |
| **min_confianza** | 0.5 |
| **lift_minimo** | 1.0 |
| **max_prof** | 3 |
| **k_beam** | 10 |
| **top_por_consecuente** | 10 |
| **pais** | ES |
| **subdiv** | nacional |
| **min_reglas_grupo** | 2 |

---

# Resumen de comportamiento: delhi

**Métrica analizada:** Meantemp  
**Total de reglas analizadas:** 19

> ### Niveles de la métrica analizada (meantemp) 
> Escala desde **excepcionalmente bajo** hasta **excepcionalmente alto**, calculada a partir de la desviación sobre la media histórica del propio sensor.
>
> Cuando el patrón es *muy diferenciado* del comportamiento normal se describe *'de forma notable'* o *'muy marcada'*. Cuando es solo una *tendencia*, se dice así.
## ¿Cómo se comporta **meantemp** a lo largo del año?
> Esta sección resume el comportamiento de **meantemp** en lenguaje sencillo, sin tecnicismos.

Verano y primavera son las épocas donde la meantemp tiende a ser **muy alta**, especialmente en junio y mayo. En invierno, en cambio, la meantemp tiende a ser **excepcionalmente baja**, con enero como el mes de mayor contraste. Otoño actúa como período de transición: la meantemp tiende a ser **baja**, con noviembre marcando ya un cambio notable.


## Patrones estacionales y de calendario

_Los siguientes patrones no están ligados a una franja horaria concreta sino a períodos del calendario con comportamiento diferencial._

- En **enero**, la meantemp tiende a ser **excepcionalmente baja (outlier inferior)** (confianza 62 %, lift 6.0).
- En **diciembre en invierno**, la meantemp tiende a ser **excepcionalmente baja (outlier inferior)** (confianza 60 %, lift 5.8).
- En **invierno**, la meantemp tiende a ser **excepcionalmente baja (outlier inferior)** (confianza 52 %, lift 5.0).

## Análisis por mes y estación

Detalle de los patrones detectados, organizados por estación y mes del año.

### Primavera

- **Muy alta** de forma muy marcada: mayo (confianza 60 %, lift 3.7)
- **Muy alta** de forma muy marcada: primavera (confianza 59 %, lift 3.6)
- **Alta** de forma notable: mayo (confianza 52 %, lift 2.1)
- **Media** de forma muy marcada: abril (confianza 61 %, lift 3.2)
- **Media** de forma notable: marzo (confianza 54 %, lift 2.8)
- **Baja** de forma notable: marzo (confianza 59 %, lift 2.6)

### Verano

- **Muy alta** de forma muy marcada: junio (confianza 66 %, lift 4.0)
- **Alta** de forma notable: verano (confianza 54 %, lift 2.2)

### Otoño

- **Alta** de forma notable: septiembre (confianza 64 %, lift 2.6)
- **Media** de forma notable: octubre (confianza 55 %, lift 2.9)
- **Baja** de forma muy marcada: noviembre (confianza 86 %, lift 3.8)

### Invierno

- **Baja** de forma notable: febrero (confianza 56 %, lift 2.4)
- **Baja** de forma notable: diciembre (confianza 54 %, lift 2.3)
- **Baja** de forma notable: los lunes en diciembre (confianza 50 %, lift 2.2)
- **Muy baja** de forma muy marcada: invierno (confianza 54 %, lift 3.2)
- **Excepcionalmente baja (outlier inferior)** de forma muy marcada: enero (confianza 62 %, lift 6.0)
- **Excepcionalmente baja (outlier inferior)** de forma muy marcada: diciembre en invierno (confianza 60 %, lift 5.8)
- **Excepcionalmente baja (outlier inferior)** de forma muy marcada: invierno (confianza 52 %, lift 5.0)

### Sin estación específica

- **Baja** de forma muy marcada: condiciones no especificadas (confianza 76 %, lift 3.3)

---

## Análisis por nivel de meantemp


> ### Glosario técnico (apéndice)
> * **Confianza:** probabilidad (0–100 %) de que el patrón sea cierto cuando se da el contexto. Confianza 80 % significa que, en ese contexto, el la métrica se comporta así 8 de cada 10 veces.
> * **Lift:** cuántas veces más probable es el evento respecto al azar. Lift 5.0 significa que el patrón es 5 veces más frecuente en ese contexto que en el resto del tiempo.
> * **Outlier inferior/superior:** valor más allá de 2 desviaciones típicas de la media histórica del sensor.

*Mismas reglas organizadas por nivel de **meantemp** (de mayor a menor valor).*

### Meantemp muy alta
*3 reglas, agrupadas en 3 contextos | confianza media: 62 %, lift medio: 3.8*

En junio, la meantemp tiende a ser muy alta de forma muy marcada (confianza 66 %, lift 4.0).

En mayo, la meantemp tiende a ser muy alta de forma muy marcada (confianza 60 %, lift 3.7).

En primavera, la meantemp tiende a ser muy alta de forma muy marcada (confianza 59 %, lift 3.6).

### Meantemp alta
*3 reglas, agrupadas en 3 contextos | confianza media: 57 %, lift medio: 2.3*

En septiembre, la meantemp tiende a ser alta de forma notable (confianza 64 %, lift 2.6).

En verano, la meantemp tiende a ser alta de forma notable (confianza 54 %, lift 2.2).

En mayo, la meantemp tiende a ser alta de forma notable (confianza 52 %, lift 2.1).

### Meantemp media
*3 reglas, agrupadas en 3 contextos | confianza media: 56 %, lift medio: 2.9*

En abril, la meantemp tiende a ser media de forma muy marcada (confianza 61 %, lift 3.2).

En octubre, la meantemp tiende a ser media de forma notable (confianza 55 %, lift 2.9).

En marzo, la meantemp tiende a ser media de forma notable (confianza 54 %, lift 2.8).

### Meantemp baja
*6 reglas, agrupadas en 6 contextos | confianza media: 63 %, lift medio: 2.8*

En noviembre, la meantemp tiende a ser baja de forma muy marcada (confianza 86 %, lift 3.8).

En condiciones no especificadas, la meantemp tiende a ser baja de forma muy marcada (confianza 76 %, lift 3.3).

En marzo, la meantemp tiende a ser baja de forma notable (confianza 59 %, lift 2.6).

En febrero, la meantemp tiende a ser baja de forma notable (confianza 56 %, lift 2.4).

En diciembre, la meantemp tiende a ser baja de forma notable (confianza 54 %, lift 2.3).

En los lunes en diciembre, la meantemp tiende a ser baja de forma notable (confianza 50 %, lift 2.2).

### Meantemp muy baja
*1 regla, agrupadas en 1 contexto | confianza media: 54 %, lift medio: 3.2*

En invierno, la meantemp tiende a ser muy baja de forma muy marcada (confianza 54 %, lift 3.2).

### Meantemp excepcionalmente baja (outlier inferior)
*3 reglas, agrupadas en 3 contextos | confianza media: 58 %, lift medio: 5.6*

En enero, la meantemp tiende a ser excepcionalmente baja (outlier inferior) de forma muy marcada (confianza 62 %, lift 6.0).

En diciembre en invierno, la meantemp tiende a ser excepcionalmente baja (outlier inferior) de forma muy marcada (confianza 60 %, lift 5.8).

En invierno, la meantemp tiende a ser excepcionalmente baja (outlier inferior) de forma muy marcada (confianza 52 %, lift 5.0).

---

## Estadísticas globales del análisis

| Métrica | Valor |
|---|---|
| Reglas totales | 19 |
| Consecuentes únicos | 6 |
| Soporte medio | 0.0970 |
| Confianza media | 59.6 % |
| Lift medio | 3.35 |
| Lift máximo | 5.97 |