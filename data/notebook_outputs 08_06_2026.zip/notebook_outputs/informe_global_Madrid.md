# Informe Global Comparativo — Sensores de tráfico de Madrid

*Generado el 2026-05-25 | 2 fuentes de datos analizadas | 71 patrones en total*

## ¿Cómo se comporta **intensidad, ocupacion** en Sensores de tráfico de Madrid?

> Esta sección resume los hallazgos principales en lenguaje sencillo, sin tecnicismos. Los detalles técnicos se encuentran en las secciones siguientes.

Se han analizado **2 fuentes de datos** de Sensores de tráfico de Madrid, detectando un total de **71 patrones** de comportamiento estadísticamente significativos.

La fuente con los patrones más marcados es **6823** (fuerza de asociación máxima: 11.6), mientras que **3600** presenta el comportamiento más uniforme (fuerza media: 3.2).

## Tabla comparativa global

Cada fila representa una fuente de datos. La columna **Perfil del día** muestra el nivel de **intensidad, ocupacion** dominante en cada franja (Madrugada | Mañana | Tarde | Noche): 🔴 excepcional · 🟠 muy alto · 🟡 alto · 🟢 moderado · 🔵 bajo · 🟣 muy bajo · ⚪ mínimo.

|   Sensor | Métrica    |   Reglas |   Conf. media (%) |   Lift medio |   Lift máx | Nivel dominante   | Perfil del día                             |   Hora más mencionada en reglas | Día más mencionado   | Outlier alto   | Outlier bajo   |
|---------:|:-----------|---------:|------------------:|-------------:|-----------:|:------------------|:-------------------------------------------|--------------------------------:|:---------------------|:---------------|:---------------|
|     3600 | intensidad |       34 |              57   |         3.18 |       6.21 | 🔵 baja            | Madrugada 🔵 | Mañana 🔵 | Tarde 🔴 | Noche 🟢 |                              18 | Domingo              | ✅              | —              |
|     6823 | ocupacion  |       37 |              63.1 |         3.33 |      11.63 | 🔵 baja            | Madrugada 🟣 | Mañana 🟢 | Tarde 🟢 | Noche 🔵 |                              11 | Domingo              | ✅              | —              |

## Análisis técnico comparativo

El presente informe agrega los resultados del análisis difuso sobre 2 fuentes de datos de Sensores de tráfico de Madrid, comprendiendo un total de 71 reglas de asociación significativas. La confianza media global es del 60.0 %. La fuente con mayor riqueza de patrones es **6823** y la de menor, **3600**. El patrón más fuerte se observa en **6823** con lift máximo de 11.6.

### Patrones compartidos entre fuentes de datos

Se identifican patrones recurrentes en al menos la mitad de los sensores, lo que sugiere regularidades temporales transversales en Sensores de tráfico de Madrid:

- 🟢 **las 9h + Sab** → media (2/2 sensores)
- 🔵 **las 0h** → baja (2/2 sensores)
- 🟡 **las 12h** → alta (2/2 sensores)

### Fuentes con comportamiento atípico

Ninguna fuente de datos muestra desviaciones marcadas respecto al comportamiento medio del grupo en las métricas globales.

### Comportamientos extremos (outliers)

🔴 Picos excepcionales detectados en: **3600, 6823**

### Comparativa de perfiles de día

Cada fuente tiene un perfil diario propio. Las fuentes con perfil idéntico comparten el mismo patrón estructural.

La fuente **3600** tiene perfil diario propio: *Madrugada 🔵 | Mañana 🔵 | Tarde 🔴 | Noche 🟢*.

La fuente **6823** tiene perfil diario propio: *Madrugada 🟣 | Mañana 🟢 | Tarde 🟢 | Noche 🔵*.

---

## Análisis detallado por fuente de datos

Para el desglose completo de reglas, visualizaciones y narrativa, consultar los informes individuales generados por `src03`:

- [3600 — Intensidad](./3600_intensidad_resumen.md)
- [6823 — Ocupacion](./6823_ocupacion_resumen.md)
