# Resumen de comportamiento — DailyDelhiClimateTrain

**Métrica analizada:** Meantemp  
**Total de reglas analizadas:** 19

> ### 📖 Niveles de la métrica analizada (meantemp) 
> Escala desde **excepcionalmente bajo** ⚪ hasta **excepcionalmente alto** 🔴, calculada a partir de la desviación sobre la media histórica del propio sensor.
>
> Cuando el patrón es *muy diferenciado* del comportamiento normal se describe *'de forma notable'* o *'muy marcada'*. Cuando es solo una *tendencia*, se dice así.
## Visualizaciones

### Mapa de calor hora × día de la semana
![Mapa de calor hora x día](data/DailyDelhiClimateTrain_heatmap.png)

### Reglas por fuerza de asociación (lift)
![Barras lift](data/DailyDelhiClimateTrain_barras_lift.png)

### Soporte vs Confianza
![Scatter soporte-confianza](data/DailyDelhiClimateTrain_scatter.png)

### Resumen por categoría
![Tabla consecuentes](data/DailyDelhiClimateTrain_tabla_consecuentes.png)

## Patrones detectados
> ℹ️ Este dataset tiene granularidad **diaria** — no hay patrones por franja horaria. Los patrones detectados son estacionales y de calendario.

## Patrones estacionales y de calendario

_Los siguientes patrones no están ligados a una franja horaria concreta sino a períodos del calendario con comportamiento diferencial._

- ⚪ En **enero**, la meantemp tiende a ser **excepcionalmente baja (outlier inferior)** (confianza 62 %, lift 6.0).
- ⚪ En **diciembre en invierno**, la meantemp tiende a ser **excepcionalmente baja (outlier inferior)** (confianza 60 %, lift 5.8).
- ⚪ En **invierno**, la meantemp tiende a ser **excepcionalmente baja (outlier inferior)** (confianza 52 %, lift 5.0).

---

## Apéndice — Análisis por nivel de meantemp


> ### 📖 Glosario técnico (apéndice)
> * **Confianza:** probabilidad (0–100 %) de que el patrón sea cierto cuando se da el contexto. Confianza 80 % significa que, en ese contexto, el la métrica se comporta así 8 de cada 10 veces.
> * **Lift:** cuántas veces más probable es el evento respecto al azar. Lift 5.0 significa que el patrón es 5 veces más frecuente en ese contexto que en el resto del tiempo.
> * **Outlier inferior/superior:** valor más allá de 2 desviaciones típicas de la media histórica del sensor.

*Mismas reglas organizadas por nivel de **meantemp** (de mayor a menor valor).*

### 🟠 Meantemp muy alta
*3 reglas — agrupadas en 3 contextos* | confianza media: 62 %, lift medio: 3.8 

En junio, la meantemp tiende a ser muy alta de forma muy marcada (confianza 66 %, lift 4.0).

En mayo, la meantemp tiende a ser muy alta de forma muy marcada (confianza 60 %, lift 3.7).

En primavera, la meantemp tiende a ser muy alta de forma muy marcada (confianza 59 %, lift 3.6).

### 🟡 Meantemp alta
*3 reglas — agrupadas en 3 contextos* | confianza media: 57 %, lift medio: 2.3 

En septiembre, la meantemp tiende a ser alta de forma notable (confianza 64 %, lift 2.6).

En verano, la meantemp tiende a ser alta de forma notable (confianza 54 %, lift 2.2).

En mayo, la meantemp tiende a ser alta de forma notable (confianza 52 %, lift 2.1).

### 🟢 Meantemp media
*3 reglas — agrupadas en 3 contextos* | confianza media: 56 %, lift medio: 2.9 

En abril, la meantemp tiende a ser media de forma muy marcada (confianza 61 %, lift 3.2).

En octubre, la meantemp tiende a ser media de forma notable (confianza 55 %, lift 2.9).

En marzo, la meantemp tiende a ser media de forma notable (confianza 54 %, lift 2.8).

### 🔵 Meantemp baja
*6 reglas — agrupadas en 6 contextos* | confianza media: 63 %, lift medio: 2.8 

En noviembre, la meantemp tiende a ser baja de forma muy marcada (confianza 86 %, lift 3.8).

En condiciones no especificadas, la meantemp tiende a ser baja de forma muy marcada (confianza 76 %, lift 3.3).

En marzo, la meantemp tiende a ser baja de forma notable (confianza 59 %, lift 2.6).

En febrero, la meantemp tiende a ser baja de forma notable (confianza 56 %, lift 2.4).

En diciembre, la meantemp tiende a ser baja de forma notable (confianza 54 %, lift 2.3).

En los lunes en diciembre, la meantemp tiende a ser baja de forma notable (confianza 50 %, lift 2.2).

### 🟣 Meantemp muy baja
*1 regla — agrupadas en 1 contexto* | confianza media: 54 %, lift medio: 3.2 

En invierno, la meantemp tiende a ser muy baja de forma muy marcada (confianza 54 %, lift 3.2).

### ⚪ Meantemp excepcionalmente baja (outlier inferior)
*3 reglas — agrupadas en 3 contextos* | confianza media: 58 %, lift medio: 5.6 

En enero, la meantemp tiende a ser excepcionalmente baja (outlier inferior) de forma muy marcada (confianza 62 %, lift 6.0).

En diciembre en invierno, la meantemp tiende a ser excepcionalmente baja (outlier inferior) de forma muy marcada (confianza 60 %, lift 5.8).

En invierno, la meantemp tiende a ser excepcionalmente baja (outlier inferior) de forma muy marcada (confianza 52 %, lift 5.0).

---

## Estadísticas globales del análisis

| Métrica | Valor |
|---|---|
| Reglas totales | 19 |
| Consecuentes únicos | 6 |
| Soporte medio | 0.0970 |
| Confianza media | 59.6 % |
| Lift medio | 3.35 |
| Lift máximo | 5.97 |